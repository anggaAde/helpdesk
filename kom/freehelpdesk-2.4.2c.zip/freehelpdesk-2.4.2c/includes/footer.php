<p><a href="http://freehelpdesk.org/" target="_blank" title="Free Help Desk ver 2.3.2"><img src="img/fhd-logo.png" alt="freehelpdesk.org " width="60" height="59" border="0" style="float: right;"></a></p>
</div>
<script src="js/parsley.min.js"></script>
<script src="js/bootstrap-alert.js"></script> 

</body>
</html>